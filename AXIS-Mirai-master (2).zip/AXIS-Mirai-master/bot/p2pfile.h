/*
 * AXIS P2P File Sharing - Pure outbound, no listening ports
 */

#ifndef _P2PFILE_H
#define _P2PFILE_H

#define P2PFILE_PORT 49153
#define CHUNK_SIZE 4096

#define P2PFILE_REQ 0x20
#define P2PFILE_DATA 0x21

void p2pfile_init(void);
int p2pfile_download(char *filename, ipv4_t seed_addr, port_t seed_port);

#endif
