#pragma once

#define HTTP_SERVER "100.104.216.92"
#define HTTP_PORT 80

#define TFTP_SERVER "100.104.216.92"
